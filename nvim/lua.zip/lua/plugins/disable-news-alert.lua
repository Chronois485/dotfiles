return {
	"LazyVim/LazyVim",
	opts = {
		news = {
			lazyvim = false,
			neovim = false,
		},
	},
}
